document.body.style.background = "#000";
/*  
    *document是获取的是网页的文档
    *body获取的是网页文档中body部分
    *style是样式属性
    *background是背景属性
    *#000是黑色
    *灰色部分是注释你可以不要输入进去
 */
